/* (Auto-generated binary data file). */

#ifndef BINARY_DPF_RESOURCES_HPP_INCLUDED
#define BINARY_DPF_RESOURCES_HPP_INCLUDED

namespace dpf_resources
{
    extern const char* dejavusans_ttf;
    const unsigned int dejavusans_ttf_size = 741536;
};

#endif
