# Information example

This example will show how to get some basic information sent to the UI.<br/>

The Plugin has a lot of parameter outputs which the UI uses to get info from.<br/>
This includes buffer-size and time position.<br/>
Sample-rate can be requested directly from the UI.<br/>
The UI will show this information as text.<br/>

The plugin will not do any audio processing.<br/>
