# Latency example

This example will show how to use latency in DPF based plugins.<br/>

The plugin will delay its audio signal by a variable amount of time, specified by a parameter.<br/>
Good hosts will receive this hint and compensate accordingly.<br/>

The plugin has no UI because there's no need for one in this case.<br/>
